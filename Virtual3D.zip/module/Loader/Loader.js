class Loader{
    constructor() {
        
    }
}