import { Entity3D, Group } from "../../Virtual3D.module.js";
class  OBJLoader {
    constructor() {

    }
    async load(url) {
        let objText = null;
        if (!url) throw new Error('URL is required');
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
            objText =  await response.text();
        } catch (error) {
            console.error('PMX Load Error:', error);
            throw error;
        }
        let model = this.parse( objText );
        return model;
    }

    parse( objText ) {
        let g = new Group();
        // 存储各类数据的数组
    const vertices = [];       // 顶点数据，每个元素是 [x, y, z]
    const uvs = [];            // 纹理坐标，每个元素是 [u, v]（可能有第三个分量，这里简化处理）
    const normals = [];        // 顶点法线，每个元素是 [nx, ny, nz]
    const faces = [];          // 面数据，每个元素存储 [顶点索引组, 纹理坐标索引组, 法线索引组]
    let mtlLib = '';           // 材质库文件名，用于后续加载 .mtl（可选，这里先记录）

    // 按行拆分文本
    const lines = objText.split('\n');
    lines.forEach(line => {
      line = line.trim();
      if (line === '' || line.startsWith('#')) {
        return; // 跳过空行和注释行
      }

      const parts = line.split(' ').filter(part => part !== '');
      const type = parts[0];
      const data = parts.slice(1);

      switch (type) {
        case 'v':
          // 解析顶点：x, y, z
          vertices.push(data.map(Number));
          break;
        case 'vt':
          // 解析纹理坐标：u, v（可能有 w，这里取前两个或三个，按需处理）
          uvs.push(data.map(Number));
          break;
        case 'vn':
          // 解析顶点法线：nx, ny, nz
          normals.push(data.map(Number));
          break;
        case 'mtllib':
          // 记录材质库文件名
          mtlLib = data[0];
          break;
        case 'f':
          // 解析面数据，处理类似 "v1/vt1/vn1 v2/vt2/vn2 ..." 格式
          const faceData = {
            vertexIndices: [],
            uvIndices: [],
            normalIndices: []
          };
          parts.slice(1).forEach(vertexPart => {
            const indices = vertexPart.split('/');
            // OBJ 索引是 1 基，转成 0 基
            const vIndex = parseInt(indices[0], 10) - 1;
            const vtIndex = indices[1] ? parseInt(indices[1], 10) - 1 : -1;
            const vnIndex = indices[2] ? parseInt(indices[2], 10) - 1 : -1;

            faceData.vertexIndices.push(vIndex);
            faceData.uvIndices.push(vtIndex);
            faceData.normalIndices.push(vnIndex);
          });
          faces.push(faceData);
          break;
        // 若有其他类型（如 o 物体名、usemtl 材质使用等），可继续扩展 case 处理
        default:
          break;
      }
    });

    // 解析完成后，这里可以使用解析好的数据
    console.log('顶点数据：', vertices);
    console.log('纹理坐标：', uvs);
    console.log('顶点法线：', normals);
    console.log('面数据：', faces);
    console.log('材质库：', mtlLib);

    // 后续可结合这些数据用于 3D 引擎渲染，比如 Three.js 的话：
    // 1. 创建几何体，填充顶点、法线、UV 等
    // 2. 根据面索引构建几何体的面
    // 3. 加载材质（若有 mtlLib，需额外 fetch 并解析 .mtl 文件，再创建材质）

        return normals;
    }
}
        // const parseOBJ = (objText) => {
        //     const lines = objText.split('\n');
        //     const vertexPositions = [];
        //     const textureCoords = [];
        //     const normals = [];
        //     const indices = [];

        //     for (let i = 0; i < lines.length; i++) {
        //         const line = lines[i].trim();
        //         if (line.startsWith('v ')) {
        //             const parts = line.split(' ').slice(1);
        //             const vertex = parts.map(parseFloat);
        //             vertexPositions.push(...vertex);
        //         } else if (line.startsWith('vt ')) {
        //             const parts = line.split(' ').slice(1);
        //             const texCoord = parts.map(parseFloat);
        //             textureCoords.push(...texCoord);
        //         } else if (line.startsWith('vn ')) {
        //             const parts = line.split(' ').slice(1);
        //             const normal = parts.map(parseFloat);
        //             normals.push(...normal);
        //         } else if (line.startsWith('f ')) {
        //             const parts = line.split(' ').slice(1);
        //             for (let j = 0; j < parts.length; j++) {
        //                 const [vertexIndex, texCoordIndex, normalIndex] = parts[j].split('/').map(index => index ? parseInt(index) - 1 : -1);
        //                 indices.push(vertexIndex);
        //             }
        //         }
        //     }
        //     return { vertexPositions, textureCoords, normals, indices };
            
        // };

//         this.loadPromise = (async () => {
//             const objText = await readOBJFile(ObjUrl);
//             if (objText && typeof objText === 'string') {
//                 const { vertexPositions, textureCoords, normals, indices } = parseOBJ(objText);
//                 this.vertices = new Float32Array( vertexPositions );
//                 this.uvs = new Float32Array( textureCoords );
//                 this.normals = new Float32Array( normals );
//                 this.index = new Uint16Array( indices );
//                 return { vertexPosition: this.vertexPosition, index: this.index };
//             } else {
//                 console.error('Invalid OBJ file content.');
//                 throw new Error('Invalid OBJ file content.');
//             }
//         })();
//     }
//     updateIndex() {}
//     updateShape() {}
// };
export { OBJLoader }
