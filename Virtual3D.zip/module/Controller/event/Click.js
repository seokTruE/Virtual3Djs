class Click {
    constructor() {
        
    }
}