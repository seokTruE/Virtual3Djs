let root_res = './res'
let svg_view = Vue.extend({
    template:`
        <div @click='clickevent'>
            <svg :viewBox="viewBoxValue" :style='styleObj'>
                <path v-bind:d="path[currentType]"/>
            </svg>
        </div>
    `,
    data() {
        return {
            size:24,
            path:{
                'right':'M20 2H22V22H20V2M2 10H18V7H2V10M8 17H18V14H8V17Z',
                'cube':"M21,16.5C21,16.88 20.79,17.21 20.47,17.38L12.57,21.82C12.41,21.94 12.21,22 12,22C11.79,22 11.59,21.94 11.43,21.82L3.53,17.38C3.21,17.21 3,16.88 3,16.5V7.5C3,7.12 3.21,6.79 3.53,6.62L11.43,2.18C11.59,2.06 11.79,2 12,2C12.21,2 12.41,2.06 12.57,2.18L20.47,6.62C20.79,6.79 21,7.12 21,7.5V16.5M12,4.15L6.04,7.5L12,10.85L17.96,7.5L12,4.15M5,15.91L11,19.29V12.58L5,9.21V15.91M19,15.91V9.21L13,12.58V19.29L19,15.91Z",
                'rewind':'M11.5,12L20,18V6M11,18V6L2.5,12L11,18Z',
                'rewind10':'M12.5,3C17.15,3 21.08,6.03 22.47,10.22L20.1,11C19.05,7.81 16.04,5.5 12.5,5.5C10.54,5.5 8.77,6.22 7.38,7.38L10,10H3V3L5.6,5.6C7.45,4 9.85,3 12.5,3M10,12V22H8V14H6V12H10M18,14V20C18,21.11 17.11,22 16,22H14A2,2 0 0,1 12,20V14A2,2 0 0,1 14,12H16C17.11,12 18,12.9 18,14M14,14V20H16V14H14Z',
                'pause':'M15,16H13V8H15M11,16H9V8H11M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z',
                'pause_o':'M13,16V8H15V16H13M9,16V8H11V16H9M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4Z',
                'forward10':'M10,12V22H8V14H6V12H10M18,14V20C18,21.11 17.11,22 16,22H14A2,2 0 0,1 12,20V14A2,2 0 0,1 14,12H16C17.11,12 18,12.9 18,14M14,14V20H16V14H14M11.5,3C14.15,3 16.55,4 18.4,5.6L21,3V10H14L16.62,7.38C15.23,6.22 13.46,5.5 11.5,5.5C7.96,5.5 4.95,7.81 3.9,11L1.53,10.22C2.92,6.03 6.85,3 11.5,3Z',
                'forward':'M13,6V18L21.5,12M4,18L12.5,12L4,6V18Z',
                'fullscreen_exit':'M14,14H19V16H16V19H14V14M5,14H10V19H8V16H5V14M8,5H10V10H5V8H8V5M19,8V10H14V5H16V8H19Z',
                'fullscreen':'M5,5H10V7H7V10H5V5M14,5H19V10H17V7H14V5M17,14H19V19H14V17H17V14M10,17V19H5V14H7V17H10Z',
                'menu_down':'M7,10L12,15L17,10H7Z',
                'menu-right':'M10,17L15,12L10,7V17Z',
                'gesture-swipe-horizontal':'M6,1L3,4L6,7V5H9V7L12,4L9,1V3H6V1M11,8A1,1 0 0,0 10,9V19L6.8,17.28H6.58C6.3,17.28 6.03,17.39 5.84,17.6L5.1,18.37L10,22.57C10.26,22.85 10.62,23 11,23H17.5A1.5,1.5 0 0,0 19,21.5V17.14C19,16.56 18.68,16.03 18.15,15.79L13.21,13.6L12,13.47V9A1,1 0 0,0 11,8Z',
            },
        }
    },
    props:{
        currentType: {
            type: String,
            default: 'cube'
        },
        fill: {
            type: String,
            default: '#ffffff'
        }
    },
    methods:{
        clickevent() {
            this.$emit('child_click')
        },
    },
    computed: {
        viewBoxValue() {
            return ` 0 0 ${this.size} ${this.size}`;
        },
        styleObj() {
            return {fill:this.fill}
        }
    },
});
let event_list = Vue.extend({
    template:`
        <div>
            <ul>
                <li v-for='( ld, index ) of eventname' v-bind:key='index' v-text='ld.text'></li>
            </ul>
        </div>
    `,
    data(){
        return {
            eventname:[
                { id:'001', text:'Import File'},
                { id:'002', text:'Import Fold'},
                { id:'003', text:'Export file'},
                { id:'004', text:'Export Fold'},
            ],
        };
    },
    props:{

    }
});
let components_switch = Vue.extend({
    template:`
        <div class='components_switch' style='width'>
            <div class='components_switch_child'></div>
        </div>
    `,
    data() {
        return {};
    },
    props:{
        type:{
            type: String,

        },
        setp:{
            type: Number,
            default: 1,
        },
        min:{
            type: Number,
            default: 0.0,
        },
        max:{
            type: Number,
            default: 1.0,
        },
        value:{
            type: Number,
            default: 0.0,
        },
        width:{
            type: Number,
            default: 20,
        },
        height:{
            type: Number,
            default: 40,
        },
        childwidth:{
            type: Number,
            default: 20,
        },
        childheight:{
            type: Number,
            default: 40,
        },
    }
})
let template_top = Vue.extend({
    template:`
        <div>
            <div class='template_top' style='top:0px;background-color:rgba(25,25,25,0);' @touchmove='preventDefault'>
                <div class='template_top_button' v-for='( dd, index ) of functionlist' v-bind:key='index' v-text='dd.text' v-on:click='openfile()'></div>
                <input type='file' ref='fileinput' v-show='false'/>
            </div>
            <div class='template_top' id='player' style='top:75px;background-color:rgb( 51, 51, 51 );' @touchmove='preventDefault'>
                <svg_view class='playerChildren' v-for="(sv, index) of icon" v-bind:key="index" v-bind:currentType='sv.PathData'></svg_view>
                <svg_view style='left:90%;position:absolute;' class='playerChildren' currentType='fullscreen' @child_click='test'></svg_view>
            </div>
        </div>
    `,
    data(){
        return {
            functionlist:[
                { id:'001', text:'File'},
                { id:'002', text:'Assets'},
                { id:'003', text:'Script'},
                { id:'004', text:'Shader'},
                { id:'005', text:'Render'},
                { id:'006', text:'Build'},
                { id:'007', text:'Window'},
                { id:'008', text:'Hlpe'},
                { id:'009', text:'Learn'},
                { id:'010', text:'Setting'}
            ],
            icon:[
                { id:'001', PathData:'rewind'},
                { id:'002', PathData:'rewind10'},
                { id:'003', PathData:'pause_o'},
                { id:'004', PathData:'forward10'},
                { id:'005', PathData:'forward'}
            ],
        }
    },
    props:{
        Width: Number,
        height: Number,
        inputstate:{
            type: Boolean,
            default: true,
        },
        fullscreens: {
            type: Function,
            default: () => {},
        },
    },
    methods:{
        test() {
            this.fullscreens();
        },
        openfile() {
            this.$refs.fileinput.click();
            console.log( this.$refs )
        },
        preventDefault(e) {
            e.preventDefault();
        }
    },
    components:{
        svg_view,
        event_list,
        components_switch
    },
    mounted(){
    }
});
// ----------------------------------------------------------
let entity3d_obj = Vue.extend({
    template:`
    <div class='entity3d_obj' >
        <svg_view v-bind:currentType='haveChild' v-bind:style='{ marginLeft: margin_l + "px" }'></svg_view>
        <svg_view v-bind:currentType='PathData'></svg_view>
        <div v-text='text' style='margin-left:5px;'></div>
    </div>
    `,
    computed: { // 自动计算
        margin_l() {
            return this.levelvalue*20;
        }
    },
    props:{
        text:{ // 几何体类型
            type:String,
            default:"Cube",
        },
        levelvalue:{
            type:Number,
            default:1,
        },
        PathData:{
            type:String,
            default:"cube",
        },
        haveChild:{
            type:String,
            default:"menu-right",
        },
        haveChildValue:{
            type:String,
            default:"menu-right",
        },
    },
    components:{
        svg_view,
    },
    data(){
        return {

        }
    },
});
let template_centre = Vue.extend({
    template:`
        <div>
            <div class='template_centre' v-bind:style='stylecentre' @touchmove='preventDefault' ref='er'>
                <div class='template_centre_left_dig' :style='bigleft'>
                    <div class='template_centre_left' v-bind:style='styleObj'
                        @touchstart='startDrag' @mousedown='startDrag'
                        @mousemove='handleDrag' @touchmove='handleDrag'
                        @mouseup='stopDrag' @touchend='stopDrag'>

                        <div class='text_1' v-on:click='setCanvas'>Scene</div>

                        <entity3d_obj text='Plane' ></entity3d_obj>
                        <entity3d_obj text='Sphere' ></entity3d_obj>
                        <entity3d_obj></entity3d_obj>
                        <entity3d_obj text='Model' ></entity3d_obj>
                    </div>

                    <div class='template_centre_centre' ref='ed'>
                        <div class='splitter'>
                            <svg_view class='playerChildren' currentType='fullscreen' fill='#ccccff' ></svg_view>
                        </div>
                        <canvas id='EngineCanvas' ref='ec' version="1.0"/>
                    </div>
                </div>
                <div class='template_centre_right'
                    @touchstart='rightstartDrag' @mousedown='rightstartDrag'
                    @mousemove='righthandleDrag' @touchmove='righthandleDrag'
                    @mouseup='rightstopDrag' @touchend='rightstopDrag'>
                    <div class='text_1'>components</div>

                    <div id='msg_view'>
                        <div class='components_t'  @click='changeShowMessage'>
                            <svg_view class='playerChildren' style='left:10px;position:absolute;' v-bind:currentType=' showMessage ? "menu_down" : "menu-right"'></svg_view>
                            Message
                        </div>
                        <div v-show='showMessage'  ref='eme'>
                            <span class='span_t'>Vertice Count: {{verticecount}}</span><br>
                            <span class='span_t'>Faces Count: {{verticecount}}</span><br>
                            <span class='span_t'>Bones Count: {{verticecount}}</span><br>
                        </div>
                    </div>

                    <div id='world_msg'>
                        <span class='components_t' @click='changeShowMatrix4' >
                            <svg_view class='playerChildren' style='left:10px;position:absolute;' v-bind:currentType=' showMatrix4 ? "menu_down" : "menu-right"'></svg_view>
                        Model Matrix4</span>
                        <div v-show='showMatrix4' ref='em'>
                            <div class='transfromc'>
                                <span class='span_t'>position</span>
                                <span>x</span>
                                <input class='input_transfrom' v-model:value='instanced.position.x' :size='inputsize'/>
                                <span>y</span>
                                <input class='input_transfrom' v-model:value='instanced.position.y' :size='inputsize'/>
                                <span>z</span>
                                <input class='input_transfrom' v-model:value='instanced.position.z' :size='inputsize'/>
                            </div>
                            <div class='transfromc'>
                                <span class='span_t'>rotation</span>
                                <span>x</span>
                                <input class='input_transfrom' v-model:value='instanced.Euler.x' v-bind:type='inputtype' :size='inputsize'/>
                                <span>y</span>
                                <input class='input_transfrom' v-model:value='instanced.Euler.x' :size='inputsize'/>
                                <span>z</span>
                                <input class='input_transfrom' v-model:value='instanced.Euler.x' :size='inputsize'/>
                            </div>
                            <div class='transfromc'>
                                <span class='span_t'>scale</span>
                                <span>x</span>
                                <input class='input_transfrom' v-model:value='instanced.scale.x' v-bind:type='inputtype' :size='inputsize'/>
                                <span>y</span>
                                <input class='input_transfrom' v-model:value='instanced.scale.x' :size='inputsize'/>
                                <span>z</span>
                                <input class='input_transfrom' v-model:value='instanced.scale.x' :size='inputsize'/>
                            </div>
                        </div>
                    </div>
                    <div id='msg_view'>
                        <div class='components_t' style='' @click='changeShowAttribute'>
                            <svg_view class='playerChildren' style='left:10px;position:absolute;' v-bind:currentType=' showAttribute ? "menu_down" : "menu-right"'></svg_view>
                            Attributes
                        </div>
                        <div v-show='showAttribute' ref='ea'>
                            <div>
                                <i class='span_t'>Material:</i>
                                <div class='div_material_c'>
                                    <div class='div_material_ct'>type:</div>
                                    <div class='div_material_cr'>Basic</div>
                                </div>
                                <div class='div_material_c'>
                                    <div class='div_material_ct'>color (rgba):</div>
                                    <div class='div_material_cr'></div>
                                </div>
                                <div class='div_material_c'>
                                    <div class='div_material_ct'>texture(diffuse):</div>
                                    <div class='div_material_cr'></div>
                                </div>
                                <div class='div_material_c'>
                                    <div class='div_material_ct'>diffuse Intensity:</div>
                                    <input class='div_material_cr'/>
                                </div>
                                <div class='div_material_c'>
                                    <div class='div_material_ct'>shininess:</div>
                                    <input class='div_material_cr'/>
                                </div>
                                <div class='div_material_c'>
                                    <div class='div_material_ct'>specular Intensity:</div>
                                    <input class='div_material_cr'/>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    `,
    data() {
        return {
            backcolor: '#ffffff',
            left:100,
            styleObj: {width: `${100}px`,},
            minleft: 100,
            maxleft: 600,
            startdata: null,
            isDragging: false,
            right: 80,
            minright:60,
            maxright:85,
            bigleft: {width: `${85}vw`,}, // 72n
            rightstartdata: null,
            rightisDragging: false,
            inputsize:3,
            inputtype:'passwword',
            showMessage: false,
            showMatrix4: false,
            showAttribute: true,

            instanced: {
                position: {x:0,y:0,z:0},
                Euler: {x:0,y:0,z:0},
                scale: {x:1,y:1,z:1},
                color: null,
                DiffuseMap: null,
            },
            verticecount: 10000,
            material:{
                type:'',
            },
        };
    },
    props:{
        centreheight:{
            default:60,
            // type:Number,
        },
    },
    methods:{
        changeShowMessage() {
            this.showMessage = !this.showMessage;
        },
        changeShowAttribute() {
            this.showAttribute = !this.showAttribute;
        },
        changeShowMatrix4() {
            this.showMatrix4 = !this.showMatrix4;
        },
        preventDefault(e) {
            e.preventDefault();
        },
        startDrag(e) {
            this.isDragging = true;
            const clientX = e.clientX ?? e.touches[0].clientX;
            this.startdata = clientX;
        },
        handleDrag(e) {
            if (!this.isDragging) return;
            const clientX = e.clientX ?? e.touches[0].clientX;
            let data = Math.abs( clientX - this.startdata);
            if ( data > 1 ) {
                this.updataDOM( clientX - this.startdata )
                // this.setCanvas();
                this.startdata = clientX;
            }
            // e.preventDefault();
        },
        stopDrag() {
            this.isDragging = false;
            this.startdata = null;
        },
        updataDOM( value ) {
            if ( (this.left + value) > this.minleft && (this.left + value) < this.maxleft ) {
                this.left = this.left + value;
                this.styleObj = {width: `${this.left}px`, } // 更新左
            } else if ( (this.left + value) < this.minleft ) {
                // this.left = 0;
            }
            if ( (this.left + value) > this.maxleft ) {
                // this.left = 700;
            }
        },

        rightstartDrag(e) {
            this.rightisDragging = true;
            const clientX = e.clientX ?? e.touches[0].clientX;
            this.rightstartdata = clientX;
        },
        righthandleDrag(e) {
            if (!this.rightisDragging) return;

            const clientX = e.clientX ?? e.touches[0].clientX;
            let data = Math.abs( clientX - this.rightstartdata);
            if ( data > 1 ) {
                if ( (this.right + (clientX - this.rightstartdata)/15) < 85 && (this.right + (clientX - this.rightstartdata)/15) > 50 ) {
                    this.rightupdataDOM( this.right + (clientX - this.rightstartdata)/15 )
                    this.rightstartdata = clientX;
                }
            }
            // e.preventDefault();
        },
        rightstopDrag() {
            this.rightisDragging = false;
            this.rightstartdata = null;
        },
        rightupdataDOM( value ) {
            this.right = value;
            this.bigleft = {width: `${this.right}vw`,};
            
        },
        setCanvas() {
            this.$refs.ec.width = this.$refs.ec.offsetWidth;
            this.$refs.ec.height = this.$refs.ec.offsetHeight;
        },
        fullscreens(e){
            this.$refs.ec.requestFullscreen();
        },
        checkdisplay(e) {
            if ( (this.$refs.ea.offsetHeight+this.$refs.ea.offsetTop) > this.$refs.er.offsetHeight) {
                this.showAttribute = false;
            }
            if ( (this.$refs.em.offsetHeight+this.$refs.em.offsetTop) > this.$refs.er.offsetHeight) {
                this.showMatrix4 = false;
            }
            if ( (this.$refs.eme.offsetHeight+this.$refs.eme.offsetTop) > this.$refs.er.offsetHeight) {
                this.showMessage = false;
            }
        }
    },
    computed: { // 自动计算
        colorstring () {
            // if ( rightisDragging ) return 
        },
        stylecentre() {
            return { height:`${this.centreheight}vh` }
        },
        Matrix4ic(){

        },
    },
    mounted(){
        this.setCanvas();
        let timer;
        window.addEventListener("load", () => {
            window.addEventListener("resize", () => {
                clearTimeout(timer);
                timer = setTimeout(() => {
                    this.setCanvas()
                    this.$refs.ec.V_msg.needUpdataCameraMatrix4 = true;
                }, 200);
            });
        });
        this.$emit('getfnfullscreens',this.fullscreens );
        this.$emit('getcheckdisplay', this.checkdisplay )
    },
    components:{
        svg_view,entity3d_obj,
    },
    directives:{
    },
});

let template_bottom = Vue.extend({
    template:`
        <div>
            <div class='template_bottom' :style='stylebottomheight'
                @touchstart='startDrag' @mousedown='startDrag'
                @mousemove='handleDrag' @touchmove='handleDrag'
                @mouseup='stopDrag' @touchend='stopDrag'>
                <div class='bottom_top'>
                    <div class='bottom_button' ref='ass' @click='sa'>Assets</div>
                    <div class='bottom_button' ref='con' @click='sc'>Console</div>
                    <div class='bottom_button' ref='per' @click='sp'>Performance</div>
                    <!--<div class='bottom_button' style='background-image:url(../../assets/images/logos/WebGPU.webp);'></div>-->
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            centreheight:75,
            startdata: null,
            isDragging: false,
            bottomheight:16,
            stylebottomheight:{height:`${16}vh`,},

            showAssets: false,
            showConsole: false,
            showPerformance: true,
        }
    },
    props: {
        checkdisplay:{
            type:Function,
            default: () => {},
        },
        setcentreheight:{
            type:Function,
            default: () => {},
        },
    },
    methods:{
        sa(){
            this.showAssets = true;
            this.showConsole = false;
            this.showPerformance = true;
            this.$refs.ass.style.backgroundColor = "#333333";
            this.$refs.con.style.backgroundColor = "#596cf9";
            this.$refs.per.style.backgroundColor = "#596cf9";
        },
        sc() {
            this.showAssets = false;
            this.showConsole = true;
            this.showPerformance = true;
            this.$refs.ass.style.backgroundColor = "#596cf9";
            this.$refs.con.style.backgroundColor = "#333333";
            this.$refs.per.style.backgroundColor = "#596cf9";
        },
        sp() {
            this.showAssets = false;
            this.showConsole = false;
            this.showPerformance = true;
            this.$refs.ass.style.backgroundColor = "#596cf9";
            this.$refs.con.style.backgroundColor = "#596cf9";
            this.$refs.per.style.backgroundColor = "#333333";
        },
        dsa() {

        },
        dsc() {

        },
        dsp() {

        },
        preventDefault(e) {
            e.preventDefault();
        },
        startDrag(e) {
            this.isDragging = true;
            const clientY = e.clientY ?? e.touches[0].clientY;
            this.startdata = clientY;
        },
        handleDrag(e) {
            e.preventDefault();
            if ( !this.isDragging ) return;
            const clientY = e.clientY ?? e.touches[0].clientY;
            let data = Math.abs( clientY - this.startdata);
            if ( data > 1 ) {    
                this.centreheight = this.centreheight + (clientY - this.startdata)/10;
                this.bottomheight = this.bottomheight - (clientY - this.startdata)/10;
                if ( this.centreheight < 0 ) {
                    this.centreheight = 0;
                    this.bottomheight = 91;
                    this.setcentreheight( this.centreheight );
                    this.updataDOM( this.bottomheight );
                    this.startdata = clientY;
                } else if ( this.centreheight > 0 && this.centreheight < 75 ) {
                    this.setcentreheight( this.centreheight );
                    this.checkdisplay();
                    this.updataDOM( this.bottomheight );
                    this.startdata = clientY;
                } else if ( this.centreheight > 75 ) {
                    this.centreheight = 75;
                    this.bottomheight = 16;
                    this.setcentreheight( this.centreheight );
                    this.updataDOM( this.bottomheight );
                    this.startdata = clientY;
                }
            }
        },
        stopDrag() {
            this.isDragging = false;
            this.startdata = null;
        },
        updataDOM( value ) {
            this.bottomheight = value;
            this.stylebottomheight = {height:`${this.bottomheight}vh`};
        },
    },
    mounted() {
        this.sp();
    }
});
const vm = new Vue({
    data: {
        centreheight:75,
        Scene:null,
        fullscreens: null,
        checkdisplay: null,
    },
    props:{
    },
    components:{
        template_top,
        template_centre,
        template_bottom,
        svg_view,
    },
    methods:{
        setcentreheight( value ){
            this.centreheight = value;
        },
        getData( value ) {
            return value *1;
        },
        bindScene() {

        },
        savefullscreen( fn ) {
            this.fullscreens = fn;
        },
        savecheckdisplay( fn ) {
            this.checkdisplay = fn;
        }
    },
    computed: { // 自动计算
        OperatingSystem() {
            const ua = navigator.userAgent;
            if (/Windows NT/i.test(ua)) {
                return "Windows";
            } else if (/Macintosh/i.test(ua)) {
                return "MacOS";
            } else if (/Android/i.test(ua)) {
                return "Android";
            } else if (/iPhone|iPad|iPod/i.test(ua)) {
                return "iOS";
            } else if (/Linux/i.test(ua)) {
                return "Linux";
            } else {
                return "Unknown";
            }
        }
    },
    watch: { //  监视函数
    },
    mounted(){ // vue完成模板的解析并把真实的DOM元素放入页面后（挂载完毕）调用mounted
    },
});
vm.$mount('#root');