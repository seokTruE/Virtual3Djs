import { Vector3 } from "../Virtual3D.module.js"
class Editor {
    constructor() {
        this.scene;
        this.data = {};
    }
    linkVue( url='' ) {
    }
    exportVueData() { // 从场景中提取数据并转化为vue能够读取的格式
        return 1;
    }
    buildLayout(){
        return 
    }
}
export { Editor }